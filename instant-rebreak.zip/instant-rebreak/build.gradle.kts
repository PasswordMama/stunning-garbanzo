plugins {
    alias(libs.plugins.fabric.loom)
}

base {
    archivesName = "instant-rebreak"
    group = "instantrebreak"
    version = "${libs.versions.minecraft.get()}-${providers.gradleProperty("mod_version").get()}"
}

repositories {
    mavenCentral()
}

dependencies {
    minecraft(libs.minecraft)
    implementation(libs.fabric.loader)
    implementation(libs.fabric.api)
}

java {
    toolchain {
        languageVersion.set(JavaLanguageVersion.of(libs.versions.jdk.get().toInt()))
    }
}

loom {
    accessWidenerPath = file("src/main/resources/instant-rebreak.classtweaker")
}

tasks.processResources {
    val props = mapOf("version" to project.version)
    inputs.properties(props)
    filesMatching("fabric.mod.json") { expand(props) }
}
