/*
 * Derived from Meteor Client (https://github.com/MeteorDevelopment/meteor-client)
 * Copyright (c) Meteor Development. Licensed under GPL-3.0.
 */

package instantrebreak.mixin;

import instantrebreak.InstantRebreak;
import net.minecraft.client.multiplayer.MultiPlayerGameMode;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(MultiPlayerGameMode.class)
public abstract class MultiPlayerGameModeMixin {
    @Inject(method = "startDestroyBlock", at = @At("HEAD"))
    private void instantrebreak$onStartDestroyBlock(BlockPos pos, Direction direction, CallbackInfoReturnable<Boolean> cir) {
        InstantRebreak.onStartBreaking(pos, direction);
    }
}
